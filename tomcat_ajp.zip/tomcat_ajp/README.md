# CNVD-2020-10487-Tomcat-Ajp-lfi
Tomcat-Ajp协议文件读取漏洞
![image](https://raw.githubusercontent.com/YDHCUI/CNVD-2020-10487-Tomcat-Ajp-lfi/master/QQ截图20200220231832.png)
